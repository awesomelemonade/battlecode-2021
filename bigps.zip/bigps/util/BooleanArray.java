package bigps.util;

// Used to keep track of which robots have been exposed
public class BooleanArray {
}
